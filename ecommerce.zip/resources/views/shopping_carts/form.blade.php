{!!Form::open(['url' => '/carrito', 'method' =>'POST', 'class'=> 'inline-block' ])!!}
    
    <input type="submit" class="btn btn-success" value="Confirmar compra">

{!!Form::close([])!!}