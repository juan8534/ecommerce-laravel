<?php $__env->startSection('content'); ?>
  <div class="#00897b teal darken-1 white-text">
    <h4 class="center big-padding">Lista de Usuarios</h4>
  </div>
  <div class="container">
    <table cellspacing="0" cellpadding="0" class="striped table">
      <thead>
        <tr>
          <th><h5>ID</h5></th>
          <th><h5>Nombre</h5></th>
          <th><h5>Correo</h5></th>
          <th><h5>Tipo de usuario</h5></th>          
          <th><h5>Acciones</h5></th>
        </tr>
      </thead>
      <tbody>
  <!--Se recorren todos los productos de la base de datos mediante la variable 'products' creada en el controlador-->
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <?php if($user->type == 'member'): ?>
                <td>Miembro</td>                                
            <?php else: ?>
                <td>Administrador</td>
            <?php endif; ?>                        
            <td class="right-align">                       
              <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn green">
                <li class= "material-icons">
                    mode_edit
                </li>
              </a>
            </td>                
            <td class="center-left">              
                <?php echo Form::open(['route' => ['users.destroy',$user->id], 'method' => 'delete','class'=>'delete_user']); ?>

                  <button class="btn red delete-user">
                    <li class= "material-icons">
                    delete
                    </li>
                  </button>
                <?php echo Form::close(); ?>                                                      
            </td>                        
          </tr>          
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>  
      </tbody>
    </table>
    <div class="right-align">
      <a href="<?php echo e(route('users.create')); ?>" class="waves-effect waves-light btn">
        Nuevo Usuario
      </a>
    </div>
  </div>

    <div id="modal-delete" class="modal">
    <div class="modal-content">
    <?php echo Form::open(['route' => ['users.destroy', $user->id], 'method' => 'DELETE']); ?>

      <h4>Eliminar usuario</h4>
      <h5>Desea eliminar el usuario?</h5>
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <input type="hidden" name="delete_id" id="send_id"/>
    </div>
    <div class="modal-footer">
        <a href="#!" class="modal-action modal-close btn green">Cancelar</a>
        <a href="<?php echo e(route('users.destroy', $user->id)); ?>" class="btn red">Eliminar </a>      
    </div>
    <?php echo Form::close(); ?>

  </div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>