<?php $__env->startSection('content'); ?>
  <div class="#00897b teal darken-1 white-text">
    <h4 class="center big-padding">Tu carrito de compras</h4>
  </div>
  <div class="container">
    <table class="responsive-table">
      <thead>
        <tr>
          <td><h5>Producto</h5></td>
          <td><h5>Precio</h5></td>
        </tr>
      </thead>
      <tbody>
       <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
         <tr>
           <td><?php echo e($product->title); ?></td>
           <td><?php echo e($product->pricing); ?></td>
         </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
       <tr>
         <td>Total</td>
         <td><?php echo e($total); ?></td>
       </tr>
      </tbody>
    </table>
    <br>
    <br>
    <div class="right-align">
      <?php echo $__env->make('shopping_carts.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>