<?php $__env->startSection('content'); ?>
<div class="#00897b teal darken-1 white-text">
    <h4 class="center big-padding">Recibo de pago</h4>
  </div>
  <div class="container">
    <div class="card large-padding">
      <h4>Tu pago fue procesado <span class="<?php echo e($order->status); ?>"><?php echo e($order->status); ?></span></h4>
      <p>Verifica los detalles de tu envio:</p>
      <div class="row large-padding">
        <div class="col-xs-6">Correo</div>
        <div class="col-xs-6"><?php echo e($order->email); ?></div>
      </div>

      <div class="row large-padding">
        <div class="col-xs-6">Dirección</div>
        <div class="col-xs-6"><?php echo e($order->line1); ?></div>
      </div>

      <div class="row large-padding">
        <div class="col-xs-6">Código postal</div>
        <div class="col-xs-6"><?php echo e($order->postal_code); ?></div>
      </div>

      <div class="row large-padding">
        <div class="col-xs-6">Ciudad</div>
        <div class="col-xs-6"><?php echo e($order->city); ?></div>
      </div>

      <div class="row large-padding">
        <div class="col-xs-6">Estado y pais</div>
        <div class="col-xs-6"><?php echo e("$order->state $order->country_code"); ?></div>
      </div>

      <div class="row large-padding">
        <div class="col-xs-6">Producto</div>
        <div class="col-xs-6"><?php echo e(""); ?></div>
      </div>

      <div class="text-center top-space">
        <a href="<?php echo e(url('/compras/'.$shopping_cart->customid)); ?>">Link permanente de tu compra</a>
      </div>


    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>