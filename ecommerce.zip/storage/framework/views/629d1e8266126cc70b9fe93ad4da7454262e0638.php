<div class="card product text-left">    
    <h3><?php echo e($product->title); ?></h3>
    <div class="row">
        <div class="col s12">
            <div class="col s6">
                <?php if($product->extension): ?>
                    <img class="product-avatar"src="<?php echo e(url("/products/images/$product->id.$product->extension")); ?>">
                <?php endif; ?>
            </div>
            <div class="col s6">
                <div class="row">
                    <h6>Descripción</h6>
                    <p>
                        <?php echo e($product->description); ?>

                    </p>                
                </div>
                <div class="row">
                    <?php if(Auth::check() && Auth::user()->type == "admin"): ?>
                    <div class="col s6 right-align">
                        <a href="<?php echo e(url("/products/".$product->id."/edit")); ?>" class="btn blue">
                            <i class="material-icons">edit</i>
                        </a>
                    </div>
                    <div class="col s3">
                        <a href="<?php echo e(route('products.destroy', $product->id )); ?>" class="btn red">
                            <li class= "material-icons">
                            delete
                            </li>
                        </a>   
                    </div>
                    <?php endif; ?>
                    <div class="col s3">
                        <?php echo $__env->make('in_shopping_carts.form', ["product" => $product], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>                                
                </div>                
            </div>
        </div>            
    </div>    
</div>