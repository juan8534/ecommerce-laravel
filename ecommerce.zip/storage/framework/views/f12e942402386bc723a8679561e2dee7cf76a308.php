  

<?php $__env->startSection('title', 'Productos Facilito'); ?>

<?php $__env->startSection('content'); ?>
  <div class="col s12 m6 center">
    <h3>Bienvenidos a compumundohipermegared</h3>
  </div>
  <div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <div class="col s12 m6">
        <div class="card">
          <div class="row">
            <div class="col s12 m6">
              <div class="waves-effect waves-block waves-light">
                <img class="activator product-avatar" src="<?php echo e(url("/products/images/$product->id.$product->extension")); ?>">
              </div>
            </div>
            <div class="s12 m6">
              <h4>Precio: <?php echo e($product->pricing); ?> </h4>               
                <?php echo Form::open(['url' => '/in_shopping_carts', 'method' => 'POST', "class" => "add-to-cart inline-block"]); ?>

                  <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                  <button class="btn waves-effect waves-light" type="submit" name="action">
                    Añadir al carrito                
                  </button>
                <?php echo Form::close([]); ?>

                <br>            
                <a href="<?php echo e(url("/products/$product->id")); ?>" class="btn blue">
                  Ver producto
                </a>
            </div>
          </div>
          <div class="card-content">
            <span class="card-title activator grey-text text-darken-4"><?php echo e($product->title); ?><i class="material-icons right">more_vert</i></span>             
          </div>
          <div class="card-reveal">
            <span class="card-title grey-text text-darken-4"><?php echo e($product->title); ?><i class="material-icons right">close</i></span>
            <p><?php echo e($product->description); ?></p>
          </div>
        </div>
      </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>  
  </div>
  <div class="center-align">
    <?php echo e($products->links()); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>