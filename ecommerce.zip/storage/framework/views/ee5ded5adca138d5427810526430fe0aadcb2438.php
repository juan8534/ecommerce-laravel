     <!-- Formulario por generado por 'Form' de laravel collective -->
     <?php echo Form::open(['url' => $url, 'method' => $method, 'files' => true]); ?>

        <div class="input-field col s6">
          <?php echo e(Form::text('title',$product->title,['class' => 'validate'])); ?> <!-- En el arreglo se agregan atributos del campo-->
          <?php echo e(Form::label('Nombre del producto')); ?>

        </div>
        <div class="input-field col s6">
          <?php echo e(Form::number('pricing',$product->pricing,['class' => 'validate'])); ?>

          <?php echo e(Form::label('Precio del producto')); ?>

        </div>                
        <div class="file-field input-field">
          <div class="btn">
            <span>Imagen</span>
            <?php echo e(Form::file('cover')); ?>

          </div>
          <div class="file-path-wrapper">
            <input class="file-path validate" type="text">
          </div>
        </div>
        <div class="input-field">
          <?php echo e(Form::textarea('description',$product->description,['class' => 'materialize-textarea'])); ?>

          <?php echo e(Form::label('Descripción del producto')); ?>

        </div>
        <br>
        <br>
        <div class="right-align">
          <a href="<?php echo e(url('/products')); ?>" class="waves-effect waves-light btn">
            VOLVER
          </a>
        <input type="submit" value="Enviar" class="btn btn-success">
        </div>
     <?php echo Form::close(); ?>

