<?php $__env->startSection('content'); ?>
  <div class="container white">
    <h4>Nuevo Usuario</h4>    
         <!-- Formulario por generado por 'Form' de laravel collective -->
    <?php echo Form::open(['route' => 'users.store','method' => 'POST']); ?>

        <div class="input-field col s6">
          <?php echo e(Form::text('name',null,['class' => 'validate'])); ?> <!-- En el arreglo se agregan atributos del campo-->
          <?php echo e(Form::label('Nombres')); ?>

        </div>     
        <div class="input-field col s6">
          <?php echo e(Form::email('email',null,['class' => 'validate'])); ?> <!-- En el arreglo se agregan atributos del campo-->
          <?php echo e(Form::label('Correo')); ?>

        </div> 
        <div class="input-field col s6">
          <?php echo e(Form::password('password',null,['class' => 'validate'])); ?> <!-- En el arreglo se agregan atributos del campo-->
          <?php echo e(Form::label('Contraseña')); ?>

        </div>   
        <div class="input-field col s6">
          <?php echo e(Form::select('type',['member' => 'Miembro',
            'admin' => 'Administrador'],null,['placeholder' => 'Tipo de usuario'])); ?> <!-- En el arreglo se agregan atributos del campo-->
        </div>        
        <br>
        <br>
        <div class="right-align">
          <a href="<?php echo e(url('/users')); ?>" class="waves-effect waves-light btn">
            VOLVER
          </a>
        <input type="submit" value="Enviar" class="btn btn-success">
        </div>
    <?php echo Form::close(); ?>


  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>