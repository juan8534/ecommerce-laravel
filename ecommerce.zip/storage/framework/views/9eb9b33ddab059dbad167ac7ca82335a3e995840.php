<?php $__env->startSection('content'); ?>
  <div class="#00897b teal darken-1 white-text">
    <h4 class="center big-padding">Lista de productos</h4>
  </div>
  <div class="container">
    <table class="striped table">
      <thead>
        <tr>
          <th><h5>ID</h5></th>
          <th><h5>Titulo</h5></th>
          <th><h5>Descripción</h5></th>
          <th><h5>Precio</h5></th>
          <th><h5>Acciones</h5></th>
        </tr>
      </thead>
      <tbody>
  <!--Se recorren todos los productos de la base de datos mediante la variable 'products' creada en el controlador-->
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <tr>
            <td><?php echo e($product->id); ?></td>
            <td><?php echo e($product->title); ?></td>            
            <td><?php echo e(str_limit($product->description, $limit = 40, $end = '...')); ?></td>
            <td><?php echo e($product->pricing); ?></td>
            <td class="td-left">
              <a href="<?php echo e(url("/products/$product->id")); ?>" class="btn blue">
                <li class= "material-icons ">
                    remove_red_eye
                </li>
              </a> 
            </td>
            <td>           
              <a href="<?php echo e(url('/products/'.$product->id.'/edit')); ?>" class="btn green">
                <li class= "material-icons">
                    mode_edit
                </li>
              </a>
            </td>                        
              <td >              
                <?php echo Form::open(['route' => ['products.destroy',$product->id], 'method' => 'delete','class'=>'delete_product']); ?>

                  <button class="btn red delete-product">
                    <li class= "material-icons">
                    delete
                    </li>
                  </button>
                <?php echo Form::close(); ?>                                                      
                </td>        
            </td>
          </tr>
          <?php echo $__env->make('modals.modalproducts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </tbody>
    </table>
    <div class="right-align">
      <a href="<?php echo e(url('/products/create')); ?>" class="waves-effect waves-light btn">
        Nuevo Producto
      </a>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>