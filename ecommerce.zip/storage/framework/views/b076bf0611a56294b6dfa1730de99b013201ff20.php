<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons ">
    <link type="text/css" rel="stylesheet" href="/ecommerce/public/plugins/css/materialize.min.css"  media="screen,projection"/>
    <link type="text/css" rel="stylesheet" href="/ecommerce/public//css/app.css"  media="screen,projection"/>    
    <link rel="stylesheet" href="../plugins/css/sweetalert.css">
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link href="<?php echo e(url('/css/app.css')); ?>" rel="stylesheet">


    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>
    <div id="app">
        <ul id="dropdown1" class="dropdown-content">
            <?php if(Auth::guest()): ?>
                <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                <li><a href="<?php echo e(url('/register')); ?>">Registrase</a></li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e(url('/logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                                  Cerrar sesion
                    </a>
                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                    </li>
            <?php endif; ?>
        </ul>
        <nav>
            <div class="nav-wrapper #004d40 teal darken-4 navigator" >     
                <ul id="nav-mobile" class="left hide-on-med-and-down">
                    <li><a href="<?php echo e(url('/')); ?>">Productos</a></li>                    
                    <!-- Dropdown Trigger -->                    
                </ul>
                <?php if(Auth::check()): ?> <!--Solo el usuario miembro puede crear articulos-->  
                 <ul class="right">  
                    <li>
                        <a class="dropdown-button right-align" href="#!" data-activates="dropdown1" 
                        aria-haspopup="true" aria-expanded="false" ><?php echo e(Auth::user()->name); ?>

                            <i class="material-icons right">arrow_drop_down</i>
                        </a>
                    </li>   
                </ul>         
                <?php if(Auth::user()->type == "admin"): ?>                                        
                <ul class="right">
                    <li>
                        <i class="material-icons">account_circle</i>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/users')); ?>">                            
                                Usuarios
                        </a>
                    </li>

                    <li>
                        <i class="material-icons">class</i>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/orders')); ?>">                            
                                Ordenes
                        </a>
                    </li>
                    <li>
                    <li>
                        <i class="material-icons">work</i>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/products')); ?>">                            
                                Administrar productos
                        </a>
                    </li>
                <?php endif; ?>   
                </ul>   
                <ul class="right">           
                    <li>
                        <i class="material-icons">shopping_cart</i>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/carrito')); ?>">                            
                                Mi carrito
                            <span class="circle-shopping-cart">
                                 <?php echo e($productsCount); ?> <!-- Muestra cuantos productos lleva el usuario en el carrito de compras-->
                            </span>
                        </a>
                    </li>                                    
                </ul>                  
                    <?php else: ?>          
                <ul class="right">
                    <li>
                        <a class="dropdown-button" href="#!" data-activates="dropdown1">Acciones
                            <i class="material-icons right">arrow_drop_down</i>
                        </a>
                    </li>                        
                    
                </ul>
                    <ul class="right">           
                    <li>
                        <i class="material-icons">shopping_cart</i>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/carrito')); ?>">                            
                                Mi carrito
                            <span class="circle-shopping-cart">
                                 <?php echo e($productsCount); ?> <!-- Muestra cuantos productos lleva el usuario en el carrito de compras-->
                            </span>
                        </a>
                    </li>                                    
                </ul>
                <?php endif; ?>
            </div>
        </nav>
        <?php echo $__env->yieldContent('content'); ?>    
                     
    </div>

    <!-- Scripts -->
    <script type="text/javascript" src="/ecommerce/public/plugins/jquery/jquery-3.2.1.min.js"></script>       
    <script type="text/javascript" src="/ecommerce/public/plugins/js/materialize.js"></script> 
    <script src="/ecommerce/public/plugins/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="/ecommerce/resources/assets/js/app.js"></script>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
